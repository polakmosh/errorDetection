
// Experiment file Coco 

// This says: "begin with the intro, then follow it with real sentences evenly
// shuffled with npi sentences, with each sentece separated by the "sep"
// item (a 1 second pause).

//document.querySelector('input').setAttribute('autofocus', 'autofocus');

// Original sequence
//var shuffleSequence = seq("consent", "demo","welcome", "instruction_check",
//                           startsWith("coco"),"debrief","exit");


// Generate Condition

const listNum = Math.ceil(3*Math.random());
var shuffleSequence = seq("consent", "demo", "welcome",
                           startsWith("coco"),"debrief","exit");

var showProgressBar = false;
//var counterOverride = 2;
                  
var defaults = [
    "DashedSentence", {mode: "self-paced reading", display: "in place"},
    "Form", {continueOnReturn: false, continueMessage: "Click here to continue with the story!"},
    "AY_Form", {continueOnReturn: true, continueMessage: null}, 
    "QuestionAlt", {randomOrder: false, presentHorizontally: true},
]; 
        
var items = [
    
["consent", "Form", {hideProgressBar: true, countsForProgressBar: false, continueMessage: null, continueOnReturn: true, consentRequired: true, html: {include: "LTEC_consent_2020.html" }} ],
["welcome", "AY_Form", {hideProgressBar: true, countsForProgressBar: false, consentRequired: true, continueMessage:"Click here to start", html: {include: "Welcome.html"}} ],
["demo", "Form", {hideProgressBar: true, countsForProgressBar: false, continueMessage: null, continueOnReturn: true, html: {include: "demographics.html" }} ],
["instruction_check", "Form", {hideProgressBar: true, countsForProgressBar: false, continueMessage: "Click here to start", html: {include: "instruction_check.html" }} ],
["debrief", "Form", {hideProgressBar: true, countsForProgressBar: false, consentRequired: true, continueMessage:"Click here to continue", html: {include: "MTurk_SONA_debrief.html" }} ],
["exit", "Form", {consentRequired: false, continueMessage:"Click here to continue", html: {include: "MTurk_SONA_exit.html" }} ],
["setcounter", "__SetCounter__", { }],

    
// Coco Study: Norming all words from the story (word-by-word)
    
["coco-cloze",   
                     "AY_Form", {html: {include: "Discourse_Cloze_pt1.html"}},
                     "Message", {transfer: 5000, continueOnReturn: false, html: {include: "photo1.html"}},
                     "AY_Form", {html: {include: "Discourse_Cloze_pt2.html"}},
                     "Message", {transfer: 5000, continueOnReturn: false, html: {include: "photo2.html"}},
                     "AY_Form", {html: {include: "Discourse_Cloze_pt3.html"}},
                     "Message", {transfer: 5000, continueOnReturn: false, html: {include: "photo3.html"}},
                     "AY_Form", {html: {include: "Discourse_Cloze_pt4.html"}},
                     "Message", {transfer: 5000, continueOnReturn: false, html: {include: "photo_halfway.html"}},
                     "AY_Form", {html: {include: "Discourse_Cloze_pt4b.html"}},
                     "Message", {transfer: 5000, continueOnReturn: false, html: {include: "photo4.html"}},
                     "AY_Form", {html: {include: "Discourse_Cloze_pt5.html"}},
                     "Message", {transfer: 5000, continueOnReturn: false, html: {include: "photo5.html"}},
                     "AY_Form", {html: {include: "Discourse_Cloze_pt6.html"}},
                     "Message", {transfer: 5000, continueOnReturn: false, html: {include: "photo6.html"}},
                     "AY_Form", {html: {include: "Discourse_Cloze_pt7.html"}},
                     "Message", {transfer: 5000, continueOnReturn: false, html: {include: "photo7.html"}},
                     "AY_Form", {html: {include: "Discourse_Cloze_pt8.html"}},
                     "Message", {transfer: 5000, continueOnReturn: false, html: {include: "photo8.html"}},
                     "AY_Form", {html: {include: "Discourse_Cloze_pt9.html"}},
                     "Message", {transfer: 5000, continueOnReturn: false, html: {include: "photo9.html"}}]
  
];

                   




